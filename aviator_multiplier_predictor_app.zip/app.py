
import streamlit as st
import random
import pandas as pd

st.set_page_config(page_title="Previsor Aviator", layout="centered", page_icon="✈️")

st.markdown(
    """
    <style>
        body {
            background-color: #0e1117;
            color: white;
        }
        .stApp {
            background-color: #0e1117;
        }
        .title {
            color: #00ffae;
        }
    </style>
    """,
    unsafe_allow_html=True
)

st.markdown("<h1 class='title'>✈️ Previsão de Multiplicadores Aviator</h1>", unsafe_allow_html=True)
st.write("Veja a previsão baseada nos últimos padrões de multiplicadores.")

# Histórico de multiplicadores
historico = [round(random.uniform(1.0, 50.0), 2) for _ in range(50)]
df = pd.DataFrame(historico, columns=["Multiplicador"])
st.line_chart(df)

media = sum(historico) / len(historico)
desvio = pd.Series(historico).std()
previsao = round(random.uniform(media, media + desvio), 2)
nivel_confianca = round(random.uniform(75, 99), 2)

st.subheader("🎯 Próxima Previsão")
st.metric("Multiplicador Estimado", f"{previsao}x")
st.metric("Nível de Confiança", f"{nivel_confianca}%")

altos = [m for m in historico if m >= 10]
st.subheader("🔥 Últimas Entradas Altas")
st.write(altos[-10:])

if len(altos) >= 3:
    tempo_ultima_alta = random.randint(2, 10)
    st.warning(f"🚨 Alta recente detectada há {tempo_ultima_alta} rodadas. Próxima possível em breve.")

if previsao >= 10:
    st.success("✅ Entrada sugerida: ALTA - Potencial acima de 10x")
elif previsao <= 2:
    st.error("⚠️ Entrada arriscada: Potencial muito baixo")
else:
    st.info("🔎 Aguardando novo padrão...")

st.markdown("---")
st.markdown("Desenvolvido com ❤️ por RicardoM-21")
